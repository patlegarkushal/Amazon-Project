<?xml version="1.0" encoding="UTF-8"?>
<FilteringTestSuiteEntity>
   <description></description>
   <name>Amazon_Dynamic_TS_HeaderButton_003</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>38876933-f78b-4282-bf36-53e1d5eab748</testSuiteGuid>
   <filteringBuiltIn>com.kms.katalon.execution.platform.DynamicBuiltInSearch</filteringBuiltIn>
   <filteringExtension></filteringExtension>
   <filteringPlugin></filteringPlugin>
   <filteringText>tag=(smoke) </filteringText>
</FilteringTestSuiteEntity>
