<?xml version="1.0" encoding="UTF-8"?>
<FilteringTestSuiteEntity>
   <description></description>
   <name>Amazon_Dynamic_TS_FooterLinks_004</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>669d277c-a12b-475d-847d-3e86eabb16fc</testSuiteGuid>
   <filteringBuiltIn>com.kms.katalon.execution.platform.DynamicBuiltInSearch</filteringBuiltIn>
   <filteringExtension></filteringExtension>
   <filteringPlugin></filteringPlugin>
   <filteringText>tag=(smoke) </filteringText>
</FilteringTestSuiteEntity>
