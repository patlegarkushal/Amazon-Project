<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_DDT_TS_Search item_002</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>20b3deef-11b3-4e39-852e-0776e9c10d3d</testSuiteGuid>
   <testCaseLink>
      <guid>311bb0e5-a9a0-49a2-bd8e-a6ac33e0ab90</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon_DDT_Test case/Amazon_DDT_TC_SearchItem_002</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>663a4a30-e48f-4f55-a255-3a7a110e4e64</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_Data file_SearchItem_002/Amazon_Excel_SearchItem_Test Data_002</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>663a4a30-e48f-4f55-a255-3a7a110e4e64</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>category</value>
         <variableId>11080513-9153-4a29-a1f2-0ed3d473bf89</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>663a4a30-e48f-4f55-a255-3a7a110e4e64</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>item</value>
         <variableId>f1216e23-4e76-4c3a-b5db-4c3c652b4c4d</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
