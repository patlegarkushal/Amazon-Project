<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_DDT_TS_SignIn_001</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>f1a4a8a3-dd9b-466d-92ea-316e2fdeeb8b</testSuiteGuid>
   <testCaseLink>
      <guid>99792fd0-a1e2-49ab-8541-335d1f5ee847</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon_DDT_Test case/Amazon_DDT_TC_SignIn_001</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>5655fd80-b778-475a-a2a1-94290015b8ab</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_Data File_SignIn_001/Amazon_Excel_SignIn_Test Data_001</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>5655fd80-b778-475a-a2a1-94290015b8ab</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>email </value>
         <variableId>df295c44-dcd2-4c60-b57c-fa7e2e027b1f</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>5655fd80-b778-475a-a2a1-94290015b8ab</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password</value>
         <variableId>9e918f33-7b2a-4621-94c5-3fa0f22fc65d</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
